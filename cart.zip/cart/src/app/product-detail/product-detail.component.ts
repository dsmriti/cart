import { Component, OnInit } from '@angular/core';
import { Product } from '../interface/product';
import { FetchdataService } from '../service/fetchdata.service';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit {
  public myarr: Product[];
  
  constructor(public fetchDataService: FetchdataService) { }

  ngOnInit() {
    //console.log(this.fetchDataService.getConfig());
    //this.fetchDataService.getData().subscribe(a=> this.myarr = a);
    //console.log("Data"+ this.a);
    this.fetch();

  //     .subscribe(data => this.config = data );
 }
  fetch(): void {
    this.fetchDataService.getData()
        .subscribe(heroes => this.myarr = heroes)
        console.log(this.myarr);
  }
}
