import { Product } from '../interface/product';
export const PRODUCTS: Product[]=[
    {
        "product_name":"MEN'S BETTER THAN NAKED&trade; JACKET",
        "product_image_url":"http://images.thenorthface.com/is/image/TheNorthFace/236x204_CLR/mens-better-than-naked-jacket-AVMH_LC9_hero.png",
        "header_top_right_text":"Shop All",
        "header_top_left_text":"Men's",
        "product_url":"http://www.thenorthface.com/catalog/sc-gear/men-39-s-better-than-naked-8482-jacket.html",
        "header_top_right_url":"http://www.thenorthface.com/en_US/shop-mens/",
        "product_cta_text":"Shop Now"
     },
     {
        "product_name":"WOMEN'S BETTER THAN NAKED&trade; JACKET",
        "product_image_url":"http://images.thenorthface.com/is/image/TheNorthFace/236x204_CLR/womens-better-than-naked-jacket-AVKL_NN4_hero.png",
        "header_top_right_text":"Shop All",
        "header_top_left_text":"Women's",
        "product_url":"http://www.thenorthface.com/catalog/sc-gear/women-39-s-better-than-naked-8482-jacket.html",
        "header_top_right_url":"http://www.thenorthface.com/en_US/shop-womens/",
        "product_cta_text":"Shop Now"
     },
     {
        "product_name":"WOMEN'S SINGLE-TRACK SHOE",
        "product_image_url":"http://images.thenorthface.com/is/image/TheNorthFace/236x204_CLR/womens-single-track-shoe-ALQF_JM3_hero.png",
        "header_top_right_text":"Shop All",
        "header_top_left_text":"Running Shoes",
        "product_url":"http://www.thenorthface.com/catalog/sc-gear/womens-single-track.html",
        "header_top_right_url":"http://www.thenorthface.com/webapp/wcs/stores/servlet/TNFSearchResult?langId=-1&amp;storeId=207&amp;catalogId=10201&amp;searchTerm=running%20shoes",
        "product_cta_text":"Shop Now"
     },
     {
        "product_name":"Enduro Boa&reg; Hydration Pack",
        "product_image_url":"http://images.thenorthface.com/is/image/TheNorthFace/236x204_CLR/enduro-boa-hydration-pack-AJQZ_JK3_hero.png",
        "header_top_right_text":"Shop All",
        "header_top_left_text":"Equipment",
        "product_url":"http://www.thenorthface.com/catalog/sc-gear/enduro-boa.html",
        "header_top_right_url":"http://www.thenorthface.com/en_US/shop-equipment/",
        "product_cta_text":"Shop Now"
     },
  
     {
        "product_name":"MEN'S BETTER THAN NAKED&trade; JACKET",
        "product_image_url":"http://images.thenorthface.com/is/image/TheNorthFace/236x204_CLR/mens-better-than-naked-jacket-AVMH_LC9_hero.png",
        "header_top_right_text":"Shop All",
        "header_top_left_text":"Men's",
        "product_url":"http://www.thenorthface.com/catalog/sc-gear/men-39-s-better-than-naked-8482-jacket.html",
        "header_top_right_url":"http://www.thenorthface.com/en_US/shop-mens/",
        "product_cta_text":"Shop Now"
     },
     {
        "product_name":"WOMEN'S BETTER THAN NAKED&trade; JACKET",
        "product_image_url":"http://images.thenorthface.com/is/image/TheNorthFace/236x204_CLR/womens-better-than-naked-jacket-AVKL_NN4_hero.png",
        "header_top_right_text":"Shop All",
        "header_top_left_text":"Women's",
        "product_url":"http://www.thenorthface.com/catalog/sc-gear/women-39-s-better-than-naked-8482-jacket.html",
        "header_top_right_url":"http://www.thenorthface.com/en_US/shop-womens/",
        "product_cta_text":"Shop Now"
     },
     {
        "product_name":"WOMEN'S SINGLE-TRACK SHOE",
        "product_image_url":"http://images.thenorthface.com/is/image/TheNorthFace/236x204_CLR/womens-single-track-shoe-ALQF_JM3_hero.png",
        "header_top_right_text":"Shop All",
        "header_top_left_text":"Running Shoes",
        "product_url":"http://www.thenorthface.com/catalog/sc-gear/womens-single-track.html",
        "header_top_right_url":"http://www.thenorthface.com/webapp/wcs/stores/servlet/TNFSearchResult?langId=-1&amp;storeId=207&amp;catalogId=10201&amp;searchTerm=running%20shoes",
        "product_cta_text":"Shop Now"
     },
     {
        "product_name":"Enduro Boa&reg; Hydration Pack",
        "product_image_url":"http://images.thenorthface.com/is/image/TheNorthFace/236x204_CLR/enduro-boa-hydration-pack-AJQZ_JK3_hero.png",
        "header_top_right_text":"Shop All",
        "header_top_left_text":"Equipment",
        "product_url":"http://www.thenorthface.com/catalog/sc-gear/enduro-boa.html",
        "header_top_right_url":"http://www.thenorthface.com/en_US/shop-equipment/",
        "product_cta_text":"Shop Now"
     }
];
