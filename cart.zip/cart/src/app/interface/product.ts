export class Product{
    product_name: string;
    product_image_url: any;
    header_top_right_text : string;
    header_top_left_text : string;
    product_url : any;
    header_top_right_url : any;
    product_cta_text : string;
}